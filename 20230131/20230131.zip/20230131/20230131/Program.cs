﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20230131
{
    class Program
    {

        static void Main(string[] args)
        {

            Console.WriteLine("Nyomd le az Entert!");
            Console.ReadLine();

        }
        static void Tomb() 
        {
            int[] v = new int[10];
            Random rnd = new Random();
            for (int v = 0;v.Length, i++)
            {

            }
        }
    }

}
