﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20230228
{
    class Program
    {
        static Random rnd = new Random();
        static int[] szamok = new int[20];
        static void Main(string[] args)
        {
            feladat1();
            feladat2();
            feladat3();
            feladat4();
            feladat5();
            feladat6();
            feladat7();
            feladat8();




            Console.WriteLine("Nyomd le az Entert!");
            Console.ReadLine();
        }
        static void feladat1()
        {

            for (int i = 0; i < szamok.Length; i++)
            {
                szamok[i] = rnd.Next(-100, 100 + 1);
                Console.Write(szamok[i]);
            }
        }
        static void feladat2()
        {


            Console.WriteLine("Összegzés tétel");
            int osszeg = 0;
            for (int i = 0; i < szamok.Length; i++)
                osszeg = osszeg + szamok[i];
            Console.WriteLine("Összeg: " + osszeg);
        }
        static void feladat3()
        {
            Console.WriteLine("Átlag");
            int osszeg = 0;
            for (int i = 0; i < szamok.Length; i++)
                osszeg = osszeg + szamok[i];
            Console.WriteLine("Átlaga:{0}  ", osszeg / szamok.Length);

        }
        static void feladat4()
        {

            int min;


            min = szamok[0];
            for (int i = 1; i < szamok.Length; i++)
                if (szamok[i] < min)
                    min = szamok[i];

            Console.WriteLine("A legkisebb elem: {0}", min);
        }
        static void feladat5()
        {

            int max;


           max = szamok[0];
            for (int i = 1; i < szamok.Length; i++)
                if (szamok[i] > max)
                    max = szamok[i];

            Console.WriteLine("A legnagyobb elem: {0}", max);
        }
        static void feladat6()
        {
            
            int c = 0;

            for (int i = 0; i < szamok.Length; i++)
                if (szamok[i] % 3==0)
                    c++;

            Console.WriteLine("Ennyi a szám szthato 3-mal: {0}", c);
        }
        static void feladat7()
        {
           
            int ker = 5; 

            bool van = false;
            for (int i = 0; i < szamok.Length; i++)
                if (szamok[i] == ker)
                    van = true;
            Console.WriteLine("Igaz-e, hogy van 5-ös a tömbben?: {0}", van);
        }
        static void feladat8()
        {
            

        }

        }
    }

